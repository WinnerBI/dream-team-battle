# Dream Team Battle

Jogo de futebol assincrono entre amigos. Cada jogador monta uma escalacao de 11
jogadores dentro de um tema (ex: apenas jogadores do Corinthians, apenas
vencedores de Bola de Ouro, apenas nomes com a letra D). Quando os dois amigos
escalam seus times, a partida e simulada e narrada, mostrando o vencedor.

## Stack

- **React + Vite** (frontend)
- **Supabase** (banco de dados + autenticacao)
- **Vercel** (deploy)

## Estrutura

```
src/
  main.jsx           -> ponto de entrada React
  App.jsx            -> componente principal, todas as telas e fluxo
  components.jsx     -> CrestSVG, PlayerPhoto, InteractiveField, PlayerPopup
  gameLogic.js       -> dados dos jogadores, temas, formacoes, validacao, simulacao
  api.js             -> funcoes que falam com o Supabase (auth, partidas)
  supabaseClient.js  -> configuracao do cliente Supabase
supabase/
  migrations/001_schema.sql -> tabelas e regras de seguranca do banco
```

## Como funciona o jogo

1. Usuario cria conta (email, senha, nome do time, brasao)
2. Cria uma partida: escolhe adversario + tema, escala seu time, envia o desafio
3. O adversario recebe "Sua vez de jogar", escala o time dele
4. Quando os dois escalaram, a partida e simulada localmente (funcao
   generateMatch em gameLogic.js) e os dois veem narracao + resultado

## Variaveis de ambiente

O projeto precisa de duas variaveis (configuradas no Vercel):

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

## Conceitos importantes para manutencao

- A base de jogadores fica em `gameLogic.js` no array `PLAYERS`. Cada jogador tem
  `nome`, `pos` (setor: GOL/DEF/MEI/ATA), `pais` (ISO2) e `temas` (lista).
- A validacao de escalacao (`validatePlayerLocal`) checa se o jogador pertence ao
  tema e se pode jogar na posicao (por adjacencia de setor).
- A simulacao (`generateMatch`) gera lances, placar e destaque sem depender de IA.
- Temas por letra aceitam qualquer nome que comece com a letra escolhida.
- Temas por nacionalidade (europeus, brasil_argentina) usam o campo `pais`.
