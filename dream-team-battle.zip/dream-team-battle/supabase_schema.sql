-- ============================================================
-- ESQUEMA DO BANCO DE DADOS - Dream Team Battle
-- Cole isto no SQL Editor do Supabase e clique em RUN
-- ============================================================

-- Tabela de perfis (dados extras de cada usuario)
create table if not exists profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  team_name text not null,
  crest_id text not null default 'c1',
  wins int not null default 0,
  losses int not null default 0,
  created_at timestamptz default now()
);

-- Tabela de partidas
create table if not exists matches (
  id uuid default gen_random_uuid() primary key,
  challenger_id uuid references profiles(id) on delete cascade not null,
  opponent_id uuid references profiles(id) on delete cascade not null,
  theme_id text not null,
  status text not null default 'aguardando',  -- aguardando | finalizada
  challenger_formation text,
  challenger_lineup jsonb,
  opponent_formation text,
  opponent_lineup jsonb,
  score_a int,
  score_b int,
  winner_id uuid,
  narration jsonb,
  destaque text,
  created_at timestamptz default now(),
  finished_at timestamptz
);

-- ============================================================
-- SEGURANCA (Row Level Security)
-- Garante que cada usuario so acessa o que deve
-- ============================================================

alter table profiles enable row level security;
alter table matches enable row level security;

-- Perfis: todos podem ler (para escolher adversario), so o dono edita o proprio
create policy "perfis_leitura_publica" on profiles
  for select using (true);

create policy "perfil_insere_proprio" on profiles
  for insert with check (auth.uid() = id);

create policy "perfil_edita_proprio" on profiles
  for update using (auth.uid() = id);

-- Partidas: participantes podem ler
create policy "partida_leitura_participantes" on matches
  for select using (auth.uid() = challenger_id or auth.uid() = opponent_id);

-- Desafiante cria a partida
create policy "partida_cria_desafiante" on matches
  for insert with check (auth.uid() = challenger_id);

-- Participantes podem atualizar (adversario escala, simulacao roda)
create policy "partida_atualiza_participantes" on matches
  for update using (auth.uid() = challenger_id or auth.uid() = opponent_id);
