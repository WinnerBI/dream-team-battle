# Dream Team Battle - Guia de Instalacao

Este guia leva voce do zero ate o jogo no ar, funcionando com multiplayer real
entre voce e seus amigos. Voce so precisa criar 2 contas gratuitas e colar
algumas coisas. Nao precisa saber programar.

Tempo estimado: ~20 minutos.

---

## VISAO GERAL

Voce vai usar dois servicos gratuitos:
- **Supabase** = o banco de dados na nuvem (guarda usuarios e partidas)
- **Vercel** = onde o jogo fica hospedado (o site que voce e seus amigos acessam)

O fluxo e: criar banco no Supabase -> subir o codigo no Vercel -> pronto.

---

## PARTE 1 - SUPABASE (o banco de dados)

### 1.1 Criar conta e projeto
1. Acesse https://supabase.com e clique em "Start your project"
2. Faca login (pode usar sua conta do GitHub ou Google)
3. Clique em "New Project"
4. De um nome (ex: "dream-team-battle"), crie uma senha para o banco
   (guarde essa senha em algum lugar) e escolha a regiao mais proxima
   (ex: South America - Sao Paulo)
5. Clique em "Create new project" e aguarde ~2 minutos

### 1.2 Criar as tabelas
1. No menu lateral esquerdo, clique em "SQL Editor"
2. Clique em "New query"
3. Abra o arquivo **supabase_schema.sql** (que veio junto), copie TODO o conteudo
4. Cole na caixa do SQL Editor
5. Clique em "Run" (ou aperte Ctrl+Enter)
6. Deve aparecer "Success. No rows returned" - deu certo!

### 1.3 Desativar confirmacao de email (importante!)
Para voce e seus amigos entrarem sem precisar confirmar email:
1. No menu lateral, va em "Authentication" > "Sign In / Providers" (ou "Providers")
2. Procure "Email" e clique para abrir as opcoes
3. DESATIVE a opcao "Confirm email" (deixe cinza/off)
4. Salve

### 1.4 Pegar as chaves
1. No menu lateral, va em "Project Settings" (o icone de engrenagem) > "API"
2. Voce vai ver dois valores importantes:
   - **Project URL** (algo como https://xxxxx.supabase.co)
   - **anon public** key (uma chave longa)
3. Deixe essa aba aberta, voce vai usar esses dois valores na Parte 3

---

## PARTE 2 - SUBIR O CODIGO NO GITHUB

O Vercel precisa pegar o codigo de algum lugar. O mais facil e o GitHub.

### 2.1 Criar repositorio
1. Acesse https://github.com e faca login (crie conta se nao tiver)
2. Clique no "+" no canto superior direito > "New repository"
3. De um nome (ex: "dream-team-battle"), deixe como "Private" se quiser
4. Clique em "Create repository"

### 2.2 Subir os arquivos
A forma mais simples, sem usar terminal:
1. Na pagina do repositorio recem-criado, clique em "uploading an existing file"
2. Arraste TODOS os arquivos e a pasta "src" que vieram no pacote
   (menos a pasta node_modules, que nem existe mais)
3. Clique em "Commit changes"

Arquivos que devem ser enviados:
- index.html
- package.json
- vite.config.js
- .gitignore
- .env.example
- supabase_schema.sql
- GUIA_DE_INSTALACAO.md
- a pasta src/ inteira (App.jsx, api.js, components.jsx, gameLogic.js, main.jsx, supabaseClient.js)

---

## PARTE 3 - VERCEL (colocar no ar)

### 3.1 Conectar
1. Acesse https://vercel.com e clique em "Sign Up"
2. Escolha "Continue with GitHub" (mais facil)
3. No painel, clique em "Add New..." > "Project"
4. Encontre seu repositorio "dream-team-battle" e clique em "Import"

### 3.2 Configurar as chaves do Supabase
Antes de clicar em Deploy, na tela de configuracao:
1. Procure a secao "Environment Variables"
2. Adicione as duas variaveis (nome exatamente como abaixo):

   Nome: VITE_SUPABASE_URL
   Valor: (cole a Project URL do Supabase)

   Nome: VITE_SUPABASE_ANON_KEY
   Valor: (cole a chave anon public do Supabase)

3. O Vercel ja detecta que e um projeto Vite automaticamente
4. Clique em "Deploy"
5. Aguarde ~1 minuto

### 3.3 Pronto!
Quando terminar, o Vercel te da um link (algo como
https://dream-team-battle.vercel.app). Esse e o SEU JOGO no ar!

---

## COMO JOGAR

1. Voce acessa o link, cria sua conta (email + senha + nome do time + brasao)
2. Seu amigo acessa o MESMO link e cria a conta dele
3. Voce clica em "Nova Partida", escolhe seu amigo, o tema, escala o time e
   envia o desafio
4. Seu amigo entra, ve "Sua vez de jogar", escala o time dele
5. Assim que ele escala, a partida e simulada e os dois veem o resultado e a
   narracao na tela "Finalizadas"

Divirta-se!

---

## PROBLEMAS COMUNS

**"Nenhum outro jogador cadastrado"** ao escolher adversario:
Seu amigo ainda nao criou a conta. Peca para ele se cadastrar primeiro.

**Erro ao entrar / criar conta:**
Verifique se voce desativou "Confirm email" no Supabase (passo 1.3).

**Tela branca depois do deploy:**
Provavelmente as variaveis de ambiente estao erradas. Confira no Vercel em
Settings > Environment Variables se os nomes estao exatos
(VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY) e refaca o deploy.

**Como atualizar o jogo depois:**
Qualquer mudanca nos arquivos do GitHub faz o Vercel refazer o deploy sozinho.
